# PythonResearch
## This repo is Primearly for me to develop using python
### Its more like a cookbook than anythong else